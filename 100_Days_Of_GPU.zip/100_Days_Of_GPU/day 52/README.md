𝐖𝐞𝐫𝐞 𝐑𝐍𝐍𝐬 𝐀𝐥𝐥 𝐖𝐞 𝐍𝐞𝐞𝐝𝐞𝐝?

I implemented this paper in pure C and AMD HIP, removing the dependency on PyTorch from the official implementation. This version is faster as it leverages accelerated functions for model construction.

Check it out here: https://github.com/a-hamdi/minimal_rnn/